<form method="post" class="form form-register">
    <span>Register to your account</span>
    <input type="text" name="registerUsername" id="registerUsername" placeholder="Username">
    <input type="password" name="RegisterPassword" id="registerPassword" placeholder="Password">
    <input type="submit" value="Register">
    <input type="hidden" name="token" id="token" value="">
    <p></p>

</form>