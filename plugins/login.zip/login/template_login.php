<form method="post" class="form form-login">
    <span>Log in to your account</span>
    <input type="text" name="username" id="username" placeholder="Username">
    <input type="password" name="password" id="password" placeholder="Password">
    <input type="submit" value="Login">
    <p></p>
</form>