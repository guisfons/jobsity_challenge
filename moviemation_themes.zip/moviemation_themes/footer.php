<?php wp_footer(); ?>
<footer class="footer">
</footer>
</body>
</html>