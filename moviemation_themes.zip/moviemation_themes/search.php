<?php

/**
 * Template Name: Search page
 * Template Post Type: page
 *
 * @package UAU
 * @since 1.0.0
 */

get_header();
?>
<main class="search-details">
<div class="lds-roller-container">
    <div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
</div>
</main>
<?php

get_footer();
