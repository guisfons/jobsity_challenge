<?php
	get_header();
?>
<section class="wrapper upcoming-movies">
	<h2>Upcoming releases</h2>

</section>

<section class="wrapper popular-actors">
	<h2>Top 10 actors</h2>
</section>
<div class="lds-roller-container">
	<div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
</div>
<?php
    get_footer();
?>