<?php

/**
 * Template Name: Actor Detail
 * Template Post Type: page
 *
 * @package UAU
 * @since 1.0.0
 */

get_header();
?>
<main class="actor">
    <section class="actor-details">
        <div class="lds-roller-container">
            <div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
        </div>
    </section>
</main>
<?php
get_footer();
