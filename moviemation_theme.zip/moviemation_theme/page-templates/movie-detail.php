<?php

/**
 * Template Name: Movie Detail
 * Template Post Type: page
 *
 * @package UAU
 * @since 1.0.0
 */

get_header();
?>
<main class="movie">
    <section class="movie-details">
    </section>
    <div class="lds-roller-container">
        <div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
    </div>
</main>
<?php

get_footer();
